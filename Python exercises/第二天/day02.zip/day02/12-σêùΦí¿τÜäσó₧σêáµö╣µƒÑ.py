#定义一个空列表
my_list = [1,2,2,2,2,2]
print(my_list)
#列表增加数据(增删改查,数据库)
#apend这个方法不会有返回结果,直接操作原本的变量
my_list.append(1)
#append在列表最后增加数据
my_list.append("大家好")
my_list.append(True)

#插入指定数据(根据指定数(下标,位置)据插入对应数据)
my_list.insert(1,"abc")
print(my_list)


my_friut = ["西瓜","芒果","草莓"]

my_list.append(my_friut)



#将列表的元素取出来,然后在拼接到原有的列表里面
my_list.extend(my_friut)
print(my_list)

#修改元素
my_list = [1,"abc","大家好","西瓜","芒果","草莓"]

my_list[0]="葡萄"

print(my_list)
#删除列表中的元素
#删除指定数据
my_list.remove("abc")

print(my_list)
#根据下标删除元素(不能列表越界,删除的下标要合法)
del my_list[0]
print(my_list)
# del my_list[4]

#使用pop的方式删除数据(pop如果不传任何参数,那么默认删除最后一个)
#将删除的数据返回给我们
result = my_list.pop()
print(my_list,result)

#判断指定数据是否在列表当中
#如果有返回TRUE 没有返回False
result = "hh" in my_list
print(result)
result = my_list.index("大家好")
print(result)
#根据指定数据获取数据在列表中的个数
my_list = [1,1,1,1,2]
result = my_list.count(5)
print(result)
