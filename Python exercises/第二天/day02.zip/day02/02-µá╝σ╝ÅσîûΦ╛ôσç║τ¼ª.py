#格式化符号:%s,%d,%f,%x
#%s:输出字符串
#%f:输出float类型
#%d输出 int类型
#%x :输出16进制的类型

name = "张三丰"
print("我叫%s"%name)

score = 100

print("python的考试分数%d"%score)

pi = 3.1415926
#%f默认保留6位小数,会四舍五入
print("圆周率%f" % pi)


num = 16
print("%x" %num)
