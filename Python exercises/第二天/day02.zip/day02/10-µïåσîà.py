#拆包:通俗理解,就是把容器类型(字符串,列表,元组,字典,集合)
#每一个数据都用变量保存一下
#字符串
my_str = "abc"
a,b,c= my_str
print(a,b,c)
#列表
my_list = [1,5]
num1,num2 = my_list
print(num1,num2)
#元组
my_tuple = (1,5)
num1,num2 = my_tuple
print(num1,num2)
#拆字典(默认拆的是key)
my_dict = {"name":"﻿余俊","age":"20"}.values()
a,b = my_dict
print(a,b)
#集合
my_set = {3,5}
num1,num2 = my_set
print(num1,num2)
#函数()