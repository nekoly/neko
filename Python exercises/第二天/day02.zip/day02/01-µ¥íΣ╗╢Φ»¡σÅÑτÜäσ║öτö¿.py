#1.接受用户输入的数据
score = int(input("请输入你的分数:"))

#判断输入的分数,根据分数输出不同的状态
#注意点判断语句只执行一次,如果不满足条件就不执行
if score >=90 and score <100:
	print("优秀")
elif score >=80 and score <90:
	print("良好")
elif score >=70 and score <80:
	print("良好")
else:
	print("及格")
