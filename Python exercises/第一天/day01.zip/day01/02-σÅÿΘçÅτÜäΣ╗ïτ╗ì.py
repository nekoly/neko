#变量的通俗理解就是存储数据的一个容器
#在内存中开辟的了一块空间,空间里面存储着score
score = 100
#变量的定义格式 :变量名 = 值 变量名见名知意
#100 数据类型 整数类型 浮点型
#定义一个字符串类型的变量
my_str = "张三"
# 数据类型 + 变量名 = 值
# int score = 100 其他语言的定义
#bool类型 真和假 非真即假
is_ok = False
print(is_ok)
#小数类型(浮点型)
pi = 3.14
my_type =type(pi)
print(my_type)

#常用的数据类型:int,str bool float list tuple dict

