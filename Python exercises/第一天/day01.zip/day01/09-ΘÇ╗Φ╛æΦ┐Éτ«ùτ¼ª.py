#逻辑运算符 and 和 or
score = 90
#and代表同时满足左右两个条件才去执行里面的代码
if score >=90 and score<=100:
	print("优秀")
num = 1
#or 只要满足左右两侧其中一个就打印
if num == 1 or num == 2:
	print("这个数字是我需要的")


#not
result = not num == 2
print(result)
if not num  == 2:
	print("hello")
