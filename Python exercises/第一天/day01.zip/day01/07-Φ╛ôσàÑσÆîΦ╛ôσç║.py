#输出:print()打印出来的(控制台)
print("helloworld")

my_str1 = "hello"
my_str2 = "world"
#输出多个变量的时候,中间会有分隔符(默认是空格)
#修改输出的分隔符
print(my_str1,my_str2,sep="&")
#print函数默认输出之后会换行
print("1",end="zhangsan")
print("2",end="\n\n")
print("3")

#输入:获取用户键盘输入的文字
result = input()

print(result)


