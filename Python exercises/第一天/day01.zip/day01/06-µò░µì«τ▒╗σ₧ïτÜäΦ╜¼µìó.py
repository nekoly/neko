num = 10
my_str = "20"
# result = num + my_str
# print(result)
#将字符串类型转换成整型
#同一数据类型才可以转换
num2 = int(my_str)

print(type(num2))

result = num+num2

print(result)
#将浮点型转换成整型
pi = 3.99
#浮点型转换成整型的时候会舍弃掉小数部分,并不是四舍五入
result = int(pi)
print(result)
#将整型转换成浮点型
result = float(num)
print(result)
#将浮点型转换成字符串类型
result = str(result)

print(type(result))

#想要转换数据类型:整型(int(),浮点型float()字符串类型,str())
#不是什么都可以转换的,要是原本类型的数据才可以转换