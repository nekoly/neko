# age = int(input("请输入你的年龄"))
#
# print(age)
# #默认你输入的文字,返回值的类型是str类型
# print(type(age))
#
# #if判断语句:满足条件才会执行代码
# #只有同种类型才可以比较
# if age >= 15 and age<=17:
#
# 	print("青少年")
# elif age >17 and age<=40:
# 	print("中年")
# else:
# 	print("老年")
#比较运算符:> < >= <= !=不等于

# = 在python 不是等于的意思,是赋值的意思 ==(代表生活中的等于)
#比较运算符使用完毕之后会返回一个bool值给我们
# reslut = 10==10
# print(reslut)
#条件为True就执行
#在计算机中,非0即真
if 0:
	print("haha")
