#列表:以中括号形式的数据集合
#列表可以存取任意类型(数组)
#数组区别:数组只能存取同种类型
my_list = [100,99.9,"abc",True]
#class:list
print(my_list,type(my_list))

#下标索引(是从0开始的)
result = my_list[1]
#将数据放入列表中不会改变其类型
print(result,type(result))
#下标:本质上是一个编号,可以根据下标取出容器中对应的元素
#python:正数下标:从0开始,0代表第一个元素
# 负数下标:从-1开始,-1代表倒数第一个元素
result = my_list[-2]
print(result)
#列表越界
#会崩溃
result = my_list[100]
print(result)



