#定义字符串"使用引号:单引号,双引号,三引号包装起来的字符
#h是hello里面的第一个元素
#下标
my_str = "hello"
print(type(my_str))
#根据指定数据查找对应的下标
#下标(索引)是从0开始的
result = my_str.index("h")
print(result)
#find和index有区别:find如果没有找到数据返回的是-1
#index如果没有找到数据,会崩溃
result = my_str.find("f")
print(result)
#统计字符串的长度
result = len(my_str)
print(result)
#统计字符串中的字符出现的次数
my_str = "hello"
result = my_str.count("l")
print(result)
#替换字符串的指定数据
result = my_str.replace("l","x")
print(result)
#字符串的分割
my_str = "苹果,橘子,鸭梨"
print(my_str)
#将字符串,包装到列表里面(分割)
#分割数据(将分割的数据包装到列表里面,对应的分割符号,就是逗号)
#如果想要分割的字符串没有逗号,会将字符串包装成列表里面的一个元素
#如果有逗号,会将字符串包装成列表的三个元素
result = my_str.split(",")
print(result)
#判断字符串是否以指定数据开头
#http:www.baidu.com file:www.baidu.com
my_url = "http://www.baidu.com"
#返回结果是bool类型
result = my_url.startswith("http")
print(result)
#判断是否以指定数据结尾
result = my_url.endswith("xxx")
print(result)
#需求:把字符串以指定数据分割成三部分
my_str = "aaabbccc"
result = my_str.partition("bb")
print(result)
flag_str = "-"
my_str = "abc"
result = flag_str.join(my_str)
print(result)
#分割列表
my_list = ["1","2","3"]
result = flag_str.join(my_list)
print(result)

#去除空格
my_str = " hel   lo "
print(my_str)
#去除左右两侧的空格(注意只去除左右)
result = my_str.strip()
print(result)
# #去除左边的空格
# result = my_str.lstrip()
# print(result)
# #去除右边的空格
# result = my_str.rstrip()
# print(result)
#去除指定数据
my_str = "bhelloa"
#注意点:默认不传参数,默认去除空格
result = my_str.strip("a")

print(result)



