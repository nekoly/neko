#关键字:在python中具有特殊功能的标识符,关键字不能作为变量名字
import keyword
kw = keyword.kwlist
print(kw)
