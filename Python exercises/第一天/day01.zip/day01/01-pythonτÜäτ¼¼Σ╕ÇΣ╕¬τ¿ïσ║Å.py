print("helloworld")
print = 10

