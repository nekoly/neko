#定义一个空列表
my_list = [1,2,2,2,2,2]
print(my_list)
#列表增加数据(增删改查,数据库)
#apend这个方法不会有返回结果,直接操作原本的变量
my_list.append(1)
#append在列表最后增加数据
my_list.append("大家好")
my_list.append(True)

#插入指定数据(根据指定数(下标,位置)据插入对应数据)
my_list.insert(1,"abc")
print(my_list)


my_friut = ["西瓜","芒果","草莓"]

my_list.append(my_friut)

#将列表的元素取出来,然后在拼接到原有的列表里面

#列表,元组,字典 for循环
